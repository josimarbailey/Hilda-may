import React from 'react'
import { Mail, Phone, Instagram, MapPin, ArrowRight, Sparkles, Star, Check } from 'lucide-react'

const Container = ({ children, className='' }) => (
  <div className={`mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 ${className}`}>{children}</div>
)

const Section = ({ id, eyebrow, title, subtitle, children, className='' }) => (
  <section id={id} className={`py-16 sm:py-20 lg:py-28 ${className}`}>
    <Container>
      {(eyebrow||title) && (
        <div className="mb-10 sm:mb-12">
          {eyebrow && <p className="uppercase tracking-wider text-xs font-semibold text-neutral-500">{eyebrow}</p>}
          {title && <h2 className="mt-2 text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-neutral-900">{title}</h2>}
          {subtitle && <p className="mt-4 text-neutral-600 max-w-3xl">{subtitle}</p>}
        </div>
      )}
      {children}
    </Container>
  </section>
)

function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-neutral-200/70 backdrop-blur bg-white/75">
      <Container className="flex h-16 items-center justify-between gap-6">
        <a href="#home" className="flex items-center gap-2 group">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-neutral-900 text-white">HM</span>
          <span className="text-sm sm:text-base font-semibold tracking-wide group-hover:opacity-90">Hilda May Events</span>
        </a>
        <nav className="hidden md:flex items-center gap-6">
          <a href="#signature" className="hover:underline">Signature</a>
          <a href="#services" className="hover:underline">Services</a>
          <a href="#pricing" className="hover:underline">Investment</a>
          <a href="#contact" className="hover:underline">Contact</a>
          <a href="mailto:info@hildamay.com" className="inline-flex items-center gap-2 rounded-full bg-neutral-900 px-4 py-2 text-white text-sm font-medium hover:bg-neutral-800 transition">
            Email Us <ArrowRight className="h-4 w-4" />
          </a>
        </nav>
      </Container>
    </header>
  )
}

function Footer() {
  return (
    <footer className="border-t border-neutral-200 py-10">
      <Container className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-neutral-600">© {new Date().getFullYear()} Hilda May Events. All rights reserved.</p>
        <div className="flex items-center gap-4 text-sm">
          <a href="#pricing" className="hover:underline">Pricing</a>
          <a href="#services" className="hover:underline">Services</a>
          <a href="#contact" className="hover:underline">Contact</a>
        </div>
      </Container>
    </footer>
  )
}

export default function App() {
  return (
    <div className="min-h-screen bg-white text-neutral-900">
      <Header />

      {/* Hero */}
      <section id="home" className="relative overflow-hidden">
        <Container className="py-20 sm:py-28 lg:py-36 grid items-center gap-10 lg:grid-cols-2">
          <div>
            <p className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-500">
              <Sparkles className="h-4 w-4" /> Premier Event Planning & Design
            </p>
            <h1 className="mt-4 text-4xl sm:text-5xl lg:text-6xl font-semibold leading-tight">
              Transforming visions into <span className="underline decoration-neutral-300">magnificent</span> realities
            </h1>
            <p className="mt-5 text-neutral-600 max-w-2xl">
              From exquisite weddings and private soirées to corporate galas and destination weekends,
              we craft unforgettable experiences with white-glove coordination, bespoke design, and elite vendor curation.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="mailto:info@hildamay.com" className="inline-flex items-center justify-center rounded-full bg-neutral-900 px-6 py-3 text-white font-medium hover:bg-neutral-800">
                Schedule Your Consultation
              </a>
              <a href="tel:+16472206104" className="inline-flex items-center justify-center rounded-full border border-neutral-300 px-6 py-3 font-medium hover:bg-neutral-50">
                Call +1 (647) 220-6104
              </a>
            </div>
          </div>
          <div className="aspect-[4/3] w-full overflow-hidden rounded-2xl shadow-xl ring-1 ring-neutral-200">
            <img src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?q=80&w=1600&auto=format&fit=crop" alt="Elegant event ambience" className="h-full w-full object-cover" />
          </div>
        </Container>
      </section>

      {/* Signature */}
      <Section id="signature" eyebrow="Our Signature" title="Unforgettable Experiences"
        subtitle="We don’t just plan events; we craft immersive moments. Every celebration is a seamless fusion of meticulous coordination and inspired design—tailored to your story.">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { title: "Bespoke Planning", desc: "From concept to grand finale, our concierge team orchestrates every detail with poise and precision." },
            { title: "Inspired Design", desc: "Refined aesthetics meet sensory excellence—florals, lighting, textures, and culinary artistry in harmony." },
            { title: "Elite Vendor Network", desc: "Access world-renowned chefs, master florists, visionary photographers, and captivating entertainers." },
          ].map((c) => (
            <div key={c.title} className="rounded-2xl border border-neutral-200 p-6">
              <h3 className="text-lg font-semibold">{c.title}</h3>
              <p className="mt-2 text-neutral-600">{c.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Services */}
      <Section id="services" eyebrow="Event Services" title="From Vision to Flawless Execution"
        subtitle="Comprehensive planning for weddings, galas, private celebrations, and corporate events—delivered with white-glove coordination and operational excellence.">
        <div className="grid gap-6 lg:grid-cols-2">
          {[
            { h: "Coordination & Vendor Curation", items: ["Timeline ownership & on-site management","Vendor selection & contracting","Budget administration","Primary point of contact"] },
            { h: "Design & Aesthetic Styling", items: ["Bespoke florals & lighting","Custom furniture & tabletop","Mood boards & sampling","Artisan collaborations"] },
            { h: "Global Event Logistics", items: ["Destination expertise","Cultural considerations","Exclusive venue sourcing","Travel & accommodations"] },
            { h: "Operational Excellence", items: ["Guest hospitality","Catering & entertainment","Technical production","Post-event wrap & returns"] },
          ].map((col) => (
            <div key={col.h} className="rounded-2xl border border-neutral-200 p-6">
              <h3 className="text-xl font-semibold">{col.h}</h3>
              <ul className="mt-4 space-y-2 text-neutral-700">
                {col.items.map(li => <li key={li} className="flex gap-3"><Check className="mt-1 h-4 w-4 shrink-0" /> {li}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* Pricing */}
      <Section id="pricing" eyebrow="Investment in Excellence" title="Services & Transparent Starting Prices"
        subtitle="Tailored proposals refined to scope, guest count, location, and vision.">
        <div className="grid gap-6 lg:grid-cols-3">
          {[
            { name:"Essential", price:"$3,500+", tagline:"Day-of Coordination", items:["Final timeline & confirmations","On-site direction & logistics","Issue triage & seamless flow"] },
            { name:"Premium", price:"$12,000+", tagline:"Partial Planning", items:["Guidance on complex elements","Vendor curation & design refinement","Integrated timelines & budget"], featured:true },
            { name:"Luxury", price:"$25,000+", tagline:"Full-Service Planning", items:["Concept-to-completion management","Bespoke design & vendor leadership","White-glove guest & operations"] },
          ].map(tier => (
            <div key={tier.name} className={`rounded-2xl border p-6 ${tier.featured?'border-neutral-900 bg-neutral-900 text-white':'border-neutral-200'}`}>
              <div className="flex items-baseline justify-between">
                <h3 className={`text-xl font-semibold ${tier.featured?'text-white':'text-neutral-900'}`}>{tier.name}</h3>
                <span className={`text-2xl font-bold ${tier.featured?'text-white':'text-neutral-900'}`}>{tier.price}</span>
              </div>
              <p className={`mt-1 text-sm ${tier.featured?'text-neutral-300':'text-neutral-600'}`}>{tier.tagline}</p>
              <ul className="mt-4 space-y-2">
                {tier.items.map(li => (
                  <li key={li} className="flex gap-3">
                    <Star className={`mt-1 h-4 w-4 shrink-0 ${tier.featured?'text-white':'text-neutral-800'}`} />
                    <span className={tier.featured?'text-neutral-100':'text-neutral-700'}>{li}</span>
                  </li>
                ))}
              </ul>
              <a href="mailto:info@hildamay.com" className={`mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full px-5 py-3 font-medium ${tier.featured?'bg-white text-neutral-900 hover:bg-neutral-100':'bg-neutral-900 text-white hover:bg-neutral-800'}`}>
                Request Bespoke Proposal <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          ))}
        </div>
      </Section>

      {/* Contact */}
      <Section id="contact" eyebrow="Contact" title="Schedule Your Consultation"
        subtitle="Tell us about your celebration—let’s explore how we can bring it to life with poise, creativity, and calm.">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="rounded-2xl border border-neutral-200 p-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <input className="w-full rounded-xl border border-neutral-300 px-4 py-3" placeholder="Full name" />
              <input className="w-full rounded-xl border border-neutral-300 px-4 py-3" placeholder="Email" type="email" />
              <input className="w-full rounded-xl border border-neutral-300 px-4 py-3 sm:col-span-2" placeholder="Event date (approx)" />
              <input className="w-full rounded-xl border border-neutral-300 px-4 py-3 sm:col-span-2" placeholder="Location / Venue" />
              <textarea className="w-full rounded-xl border border-neutral-300 px-4 py-3 sm:col-span-2" placeholder="Tell us about your vision" rows={5} />
            </div>
            <div className="mt-5 flex flex-wrap gap-3">
              <a href="mailto:info@hildamay.com" className="inline-flex items-center gap-2 rounded-full bg-neutral-900 px-5 py-3 text-white font-medium hover:bg-neutral-800">
                Email Us <ArrowRight className="h-4 w-4" />
              </a>
              <a href="tel:+16472206104" className="inline-flex items-center gap-2 rounded-full border border-neutral-300 px-5 py-3 font-medium hover:bg-neutral-50">
                Call +1 (647) 220-6104
              </a>
            </div>
          </div>

          <div className="rounded-2xl bg-neutral-50 p-6 ring-1 ring-neutral-200">
            <div className="flex flex-col gap-3 text-neutral-700">
              <div className="flex items-center gap-3"><Mail className="h-4 w-4" /> Info@hildamay.com</div>
              <div className="flex items-center gap-3"><Phone className="h-4 w-4" /> +1 (647) 220-6104</div>
              <div className="flex items-center gap-3"><Instagram className="h-4 w-4" /> @HildaMay_Events</div>
              <div className="flex items-center gap-3"><MapPin className="h-4 w-4" /> New York • London • Paris</div>
            </div>
            <div className="mt-6 aspect-[16/9] overflow-hidden rounded-xl ring-1 ring-neutral-200">
              <img src="https://images.unsplash.com/photo-1519710884002-9d5859d274f8?q=80&w=1600&auto=format&fit=crop" alt="Luxury table setting" className="h-full w-full object-cover" />
            </div>
          </div>
        </div>
      </Section>

      <Footer />
    </div>
  )
}
